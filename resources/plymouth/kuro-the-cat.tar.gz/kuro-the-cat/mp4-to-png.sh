ffmpeg -i ./input/video.mp4 ./output/progress-%01d.png -hide_banner
